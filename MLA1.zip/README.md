# Machine_Learning_A1
COMP30027 assignment 1

Alec Yu 993433, Mike Jaworski 833751

We have included our own header files to import in alongside the .data files, as they do not have a header. These header files are to remain in the datasets folder with the .data files.

In order to run our model through a file, make sure the datasets folder is in the same directory as the notebook. 

There is a model workflow provided in the notebook. In order to change the dataset for our model, assign the "filename" variable to be the name of the dataset. To run our code for this specific dataset, run the example workflow cell in the notebook.

The cell above the workflow will provide a list of all the datasets available, as well as further instructions should you require them.

